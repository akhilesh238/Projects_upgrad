#!/usr/bin/env python
# coding: utf-8

# ## Importing the libraries

# In[1]:


import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import warnings
warnings.filterwarnings('ignore')
get_ipython().system('pip install plotly')
import plotly.express as px


# In[2]:


# Reading the data set 'application_data' in app_data

app_data = pd.read_csv('application_data (1).csv')


# In[3]:


#Printing the head of the data frame.
pd.set_option('display.max_columns', None)
app_data.head()


# In[4]:


# Looking for number of rows and columns in the data frame.
app_data.shape


# In[5]:


# checking the data types of columns
app_data.dtypes.head(51)


# In[6]:


# Checking the statistical summary of Numeric Columns.

app_data.describe()


# # Cheking the percentage of Null values in the columns

# In[7]:


# Checking the null values in the dataset.
null = app_data.isnull().sum()


# In[8]:


null


# In[9]:


#FInding the percentage of null values in the dataset.
null_per = (null/app_data.shape[0])*100


# In[10]:


null_per.sort_values(ascending= False).head(60)


# ## Dropping the Null values greater then 40%

# In[11]:


# Finding the columns to be dropped
drop_columns = null_per[null_per >40].index


# In[12]:


app_data.drop(drop_columns,axis = 1,inplace = True)


# In[13]:


# Checking the rows and columns after dropping the columns
app_data.shape


# In[14]:


app_data.info()


# ## Impute/replace Missing values in rows

# In[15]:


#count of missing values in OCCUPATION_TYPE column

app_data.OCCUPATION_TYPE.isnull().sum()


# In[16]:


# Replacing the values in OCCUPATION_TYPE column with mode values.

occ_mode = app_data.OCCUPATION_TYPE.mode()
occ_mode[0]


# In[17]:


app_data.OCCUPATION_TYPE.value_counts()


# In[18]:


app_data.OCCUPATION_TYPE.fillna(occ_mode[0],inplace = True)


# In[19]:


app_data.OCCUPATION_TYPE.value_counts()


# In[20]:


app_data.OCCUPATION_TYPE.isnull().sum()


# In[21]:


#ORGANIZATION_TYPE Column

app_data.ORGANIZATION_TYPE.value_counts()


# In[22]:


# Replacing XNA values with NaN as the XNA values are large in number thus replace/imputing the value may distort the results.
app_data.ORGANIZATION_TYPE = app_data.ORGANIZATION_TYPE.replace('XNA',np.NaN)


# In[23]:


app_data.ORGANIZATION_TYPE.value_counts()


# ## Replacing NaN values with Median values for numeric columns.
# 

# In[24]:


#AMT_REQ_CREDIT_BUREAU_HOUR Column

(app_data.AMT_REQ_CREDIT_BUREAU_HOUR.value_counts(normalize = True))*100


# In[25]:


app_data.AMT_REQ_CREDIT_BUREAU_HOUR.median()


# In[26]:


app_data.AMT_REQ_CREDIT_BUREAU_HOUR.fillna(app_data.AMT_REQ_CREDIT_BUREAU_HOUR.median(),inplace = True)


# In[27]:


app_data.AMT_REQ_CREDIT_BUREAU_HOUR.isnull().sum()


# In[28]:


#AMT_REQ_CREDIT_BUREAU_DAY

(app_data.AMT_REQ_CREDIT_BUREAU_DAY.value_counts(normalize = True))*100


# In[29]:


app_data.AMT_REQ_CREDIT_BUREAU_DAY.median()


# In[30]:


app_data.AMT_REQ_CREDIT_BUREAU_DAY.fillna(app_data.AMT_REQ_CREDIT_BUREAU_DAY.median(),inplace = True)


# In[31]:


app_data.AMT_REQ_CREDIT_BUREAU_DAY.isnull().sum()


# In[32]:


#AMT_REQ_CREDIT_BUREAU_WEEK column

(app_data.AMT_REQ_CREDIT_BUREAU_WEEK.value_counts(normalize = True))*100


# In[33]:


app_data.AMT_REQ_CREDIT_BUREAU_WEEK.fillna(app_data.AMT_REQ_CREDIT_BUREAU_DAY.median(),inplace = True)


# In[34]:


app_data.AMT_REQ_CREDIT_BUREAU_WEEK.isnull().sum()


# In[35]:


#AMT_REQ_CREDIT_BUREAU_MON Column

(app_data.AMT_REQ_CREDIT_BUREAU_MON.value_counts(normalize = True))*100


# In[36]:


app_data.AMT_REQ_CREDIT_BUREAU_MON.median()


# In[37]:


app_data.AMT_REQ_CREDIT_BUREAU_MON.fillna(app_data.AMT_REQ_CREDIT_BUREAU_MON.median(),inplace = True)


# In[38]:


app_data.AMT_REQ_CREDIT_BUREAU_MON.isnull().sum()


# In[39]:


#AMT_REQ_CREDIT_BUREAU_YEAR

(app_data.AMT_REQ_CREDIT_BUREAU_YEAR.value_counts(normalize = True))*100


# In[40]:


app_data.AMT_REQ_CREDIT_BUREAU_YEAR.median()


# In[41]:


app_data.AMT_REQ_CREDIT_BUREAU_YEAR.fillna(app_data.AMT_REQ_CREDIT_BUREAU_YEAR.median(),inplace = True)


# In[42]:


#AMT_REQ_CREDIT_BUREAU_QRT

(app_data.AMT_REQ_CREDIT_BUREAU_QRT.value_counts(normalize = True))*100


# In[43]:


app_data.AMT_REQ_CREDIT_BUREAU_QRT.median()


# In[44]:


app_data.AMT_REQ_CREDIT_BUREAU_QRT.fillna(app_data.AMT_REQ_CREDIT_BUREAU_QRT.median(),inplace = True)


# In[45]:


app_data.info()


# # Finding anomilies in Dtypes of the columns and fixing the same

# In[46]:


# Using Describe function to understand the numerical columns.

app_data.describe()


# #### Standardising Values

# In[47]:


## As we can see DAYS_BIRTH	DAYS_EMPLOYED	DAYS_REGISTRATION	DAYS_ID_PUBLISH have negative values which is not appropriate.
# converting the negative values in absolute values for the aforementioned columns.
 
app_data.DAYS_BIRTH = abs(app_data.DAYS_BIRTH)
app_data.DAYS_EMPLOYED = abs(app_data.DAYS_EMPLOYED)
app_data.DAYS_REGISTRATION = abs(app_data.DAYS_REGISTRATION)
app_data.DAYS_ID_PUBLISH = abs(app_data.DAYS_ID_PUBLISH)


# In[48]:


#Converting the values of Above columns into Years

app_data.DAYS_BIRTH = (app_data.DAYS_BIRTH//365).astype('int32')
app_data.DAYS_EMPLOYED = (app_data.DAYS_EMPLOYED//365).astype('int32')
app_data.DAYS_REGISTRATION = (app_data.DAYS_REGISTRATION//365).astype('int32')
app_data.DAYS_ID_PUBLISH = (app_data.DAYS_ID_PUBLISH//365).astype('int32')


# In[49]:


app_data


# In[50]:


app_data.info()


# In[51]:


# CODE_GENDER Column

app_data.CODE_GENDER.unique()


# In[52]:


app_data.CODE_GENDER.value_counts()


# In[53]:


#Replacing XNA values with NaN.

app_data.CODE_GENDER = app_data.CODE_GENDER.replace('XNA',np.NaN)


# In[54]:


app_data.CODE_GENDER.value_counts()


# ### Working on income columns

# In[55]:


# AMT_INCOME_TOTAL
(app_data.AMT_INCOME_TOTAL.describe())


# In[56]:


app_data.AMT_INCOME_TOTAL.quantile([0.20,0.40,0.60,0.80,0.99])


# In[57]:


#Creating Bucket for AMT_INCOME_TOTAL
app_data['AMT_INCOME_BUCKET'] = pd.cut(app_data.AMT_INCOME_TOTAL, [0,99000,135000,162000,225000,472500,999999999],labels = ['Very Low','Low','Medium','High','Very High','Extreme'])


# In[58]:


app_data.AMT_INCOME_BUCKET.value_counts()


# In[59]:


#AMT_CREDIT Bucket

app_data.AMT_CREDIT.quantile([0.20,0.40,0.60,0.80,0.99])


# In[60]:


app_data.AMT_CREDIT.describe()


# In[61]:


app_data['AMT_CREDIT_BUCKET'] = pd.cut(app_data.AMT_INCOME_TOTAL, [0,254700,432000,604152,900000,1854000,999999999],labels = ['Very Low','Low','Medium','High','Very High','Extreme'])


# In[62]:


app_data.AMT_CREDIT_BUCKET.value_counts()


# # Finding Outliers

# #### Age Variable

# In[63]:


# DAYS_BIRTH

app_data['AGE_IN_YEARS'] = app_data.DAYS_BIRTH


# In[64]:


app_data.drop('DAYS_BIRTH',axis = 1)


# In[65]:


app_data.AGE_IN_YEARS.describe()


# In[66]:


# Plotting Hstogram for the age varaible

plt.hist(app_data.AGE_IN_YEARS,bins = 70)
plt.show()


# In[67]:


#Boxplot for age variable

sns.boxplot(data = app_data.AGE_IN_YEARS)
plt.show()


# In[68]:


# Converting DAYS_EMPLOYED to YEARS_EMPLOYED
app_data['YEARS_EMPLOYED'] = app_data.DAYS_EMPLOYED
app_data.drop('DAYS_EMPLOYED',axis = 1)
plt.hist(app_data.YEARS_EMPLOYED)
plt.show()


# In[69]:


sns.boxplot(data = app_data.YEARS_EMPLOYED)
plt.show()


# In[70]:


sns.boxplot(data = app_data.YEARS_EMPLOYED.quantile([0,0.81]))
plt.show()


# #### Income Variable

# In[71]:


# AMT_INCOME_TOTAL

app_data.AMT_INCOME_TOTAL.describe()


# In[72]:


app_data.AMT_INCOME_TOTAL


# In[73]:


plt.figure(figsize=[8,8])
sns.boxplot(app_data.AMT_INCOME_TOTAL)
plt.show()


# #### Credit available 

# In[74]:


#AMT_CREDIT

app_data.AMT_CREDIT.describe()


# In[75]:


plt.figure(figsize=[8,2])

sns.boxplot(app_data.AMT_CREDIT)
plt.show()


# In[76]:


#AMT_ANNUITY
app_data.AMT_ANNUITY.describe()


# In[77]:


sns.boxplot(app_data.AMT_ANNUITY)


# # Univariate Analysis

# #### Marital Status

# In[78]:


#NAME_FAMILY_STATUS	
app_data.NAME_FAMILY_STATUS.value_counts()


# In[79]:


app_data.NAME_FAMILY_STATUS.replace('Unknown',np.NaN,inplace = True)


# In[80]:


app_data.NAME_FAMILY_STATUS.value_counts()


# In[81]:


app_data.NAME_FAMILY_STATUS.value_counts(normalize = True).plot.barh()
plt.show()


# #### Income Type

# In[82]:


#NAME_INCOME_TYPE
app_data.NAME_INCOME_TYPE.value_counts()


# In[83]:


app_data.NAME_INCOME_TYPE.value_counts().plot.barh()
plt.show()


# #### Education 

# In[84]:


#NAME_EDUCATION_TYPE

app_data.NAME_EDUCATION_TYPE.value_counts()


# In[85]:


app_data.NAME_EDUCATION_TYPE.value_counts().plot.barh()
plt.show()


# ### Target Variable

# In[86]:


# TARGET
app_data.TARGET.value_counts(normalize = True)


# In[87]:


app_data.TARGET.value_counts(normalize = True).plot.pie()
plt.show()


# #### Gender

# In[88]:


#CODE_GENDER
app_data.CODE_GENDER.value_counts()


# In[89]:


app_data.CODE_GENDER.value_counts(normalize = True).plot.bar()
plt.show()


# #### OCCUPATION TYPE

# In[90]:


#OCCUPATION_TYPE
app_data.OCCUPATION_TYPE.value_counts()


# In[91]:


plt.figure(figsize=[8,8])

app_data.OCCUPATION_TYPE.value_counts().plot.barh()
plt.show()


# #### ORGANIZATION TYPE

# In[92]:


plt.figure(figsize=[10,10])

app_data.ORGANIZATION_TYPE.value_counts().plot.barh()
plt.show()


# In[ ]:





# # Bivariate and Multivariate Analysis

# In[93]:


# Income VS Credit Balance
plt.figure(figsize=[8,8])
sns.scatterplot(x = app_data.AMT_INCOME_TOTAL, y= app_data.AMT_CREDIT)
plt.show()


# In[94]:


# Income VS Annuity
sns.scatterplot(x = app_data.AMT_INCOME_TOTAL, y= app_data.AMT_ANNUITY)
plt.show()


# In[95]:


sns.scatterplot(x = app_data.AMT_INCOME_TOTAL, y= app_data.AMT_CREDIT)

plt.show()


# In[96]:


# Creating multiple scatterplots through pairplot for AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','AGE_IN_YEARS to find the linear relation between them.

sns.pairplot(data = app_data,vars = ['AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','AGE_IN_YEARS'])
plt.show()


# In[97]:


# Creating heatmap to understand the correlation for AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','AGE_IN_YEARS to find the linear relation between them.
sns.heatmap(app_data[['AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','AGE_IN_YEARS']].corr(),annot=True,cmap = 'Reds')
plt.show()


# In[98]:


#Dropping the rows where YEars_Employed is greater then 50

app_data.YEARS_EMPLOYED = app_data.YEARS_EMPLOYED.apply(lambda x: x if x < 50 else None)
        


# In[99]:


# Creating multiple scatterplots through pairplot for AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','YEARS_EMPLOYED' to find the linear relation between them.
sns.pairplot(data = app_data,vars = ['AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','YEARS_EMPLOYED'])
plt.show()


# In[100]:


sns.heatmap(app_data[['AMT_INCOME_TOTAL','AMT_ANNUITY','AMT_CREDIT','YEARS_EMPLOYED']].corr(),annot=True,cmap = 'Reds')
plt.show()


# In[101]:


# AMT_AMT_INCOME_TOTAL vs Target

app_data.groupby(by = 'TARGET')['AMT_INCOME_TOTAL'].mean()


# In[102]:


app_data.groupby(by = 'TARGET')['AMT_INCOME_TOTAL'].median()


# In[103]:



sns.boxplot(app_data.TARGET,app_data.AMT_INCOME_TOTAL)
plt.show()


# In[104]:


#For 95 Percentile
def q85(x):
    return np.quantile(x, 0.85)


# In[105]:


app_data.groupby(by = 'TARGET')['AMT_INCOME_TOTAL'].aggregate(['mean','median',q85]).plot.bar()
plt.show()


# In[106]:


# TARGET VS AMT_CREDIT

app_data.groupby(by = 'TARGET')['AMT_CREDIT'].mean()


# In[107]:


app_data.groupby(by = 'TARGET')['AMT_CREDIT'].median()


# In[108]:


sns.boxplot(app_data.TARGET,app_data.AMT_CREDIT)
plt.show()


# In[109]:


# NAME_EDUCATION_TYPE VS AMT_INCOME_TOTAL

app_data.groupby(by = 'NAME_EDUCATION_TYPE')['AMT_INCOME_TOTAL'].mean()


# In[110]:


app_data.groupby(by = 'NAME_EDUCATION_TYPE')['AMT_INCOME_TOTAL'].median()


# In[111]:


#OCCUPATION_TYPE vs AMT_INCOME_TOTAL
app_data.groupby(by = 'OCCUPATION_TYPE')['AMT_INCOME_TOTAL'].mean().plot.barh()
plt.show()


# In[112]:


app_data.groupby(by = 'OCCUPATION_TYPE')['AMT_INCOME_TOTAL'].median().plot.barh()
plt.show()


# In[113]:


#ORGANIZATION_TYPE vs AMT_INCOME_TOTAL
plt.figure(figsize=[10,10])
app_data.groupby(by = 'ORGANIZATION_TYPE')['AMT_INCOME_TOTAL'].mean().plot.barh()
plt.show()


# # Analysis of Target Variable with other variables

# In[114]:


## NAME_EDUCATION_TYPE VS TARGET
app_data.groupby(by = 'NAME_EDUCATION_TYPE')['TARGET'].mean()


# In[115]:


#Creating a bar plot to understand the relation between TARGET Column and Education.
sns.barplot(data = app_data,x = 'TARGET',y = 'NAME_EDUCATION_TYPE')
plt.show()


# In[116]:


# OCCUPATION vs TARGET
app_data.groupby(by = 'OCCUPATION_TYPE')['TARGET'].mean()


# In[117]:


#Creating a bar plot to understand the relation between TARGET Column and OCCUPATION_TYPE.
sns.barplot(data = app_data,x = 'TARGET',y = 'OCCUPATION_TYPE')
plt.show()


# In[118]:


#Creating a bar plot to understand the relation between TARGET Column and NAME_INCOME_TYPE.

sns.barplot(data = app_data,x = 'TARGET',y = 'NAME_INCOME_TYPE')
plt.show()


# In[119]:


#Creating a bar plot to understand the relation between TARGET Column and NAME_CONTRACT_TYPE.

sns.barplot(data = app_data,x = 'TARGET',y = 'NAME_CONTRACT_TYPE')
plt.show()


# In[120]:


#ORGANIZATION_TYPE vs TARGET
plt.figure(figsize=[10,10])
app_data.groupby(by = 'ORGANIZATION_TYPE')['TARGET'].mean().plot.barh()
plt.show()


# In[121]:


#AGE_IN_YEARS VS Target

sns.boxplot(app_data.TARGET,app_data.AGE_IN_YEARS)
plt.show()


# In[122]:


# Years EMPloyed VS TARGET
sns.boxplot(app_data.TARGET,app_data.YEARS_EMPLOYED)
plt.show()


# In[125]:


##Creating a BOX plot to understand the relation between TARGET Column and YEARS_EMPLOYED.

plt.figure(figsize= [8,8])
sns.boxplot(app_data.TARGET,app_data.YEARS_EMPLOYED)
plt.show()


# In[126]:


# Creating a bucket for Age column

app_data['Age_bucket'] = pd.cut(app_data.AGE_IN_YEARS,[0,30,40,50,60,100], labels = ['<30','30-40','40-50','50-60','60+'])


# In[127]:


app_data.Age_bucket.value_counts()


# In[128]:


sns.barplot(data = app_data,x = 'TARGET',y = 'Age_bucket')
plt.show()


# In[130]:


# Creating a bucket for Years Employed 

app_data['Years_employed_bucket'] = pd.cut(app_data.YEARS_EMPLOYED,[0,4,10,15,20,25,30,60], labels = ['0-4','4-10','10-15','15-20','20-25','25-30','30+'])


# In[131]:


app_data.Years_employed_bucket.value_counts()


# In[132]:


sns.barplot(data = app_data,x = 'TARGET',y = 'Years_employed_bucket')
plt.show()


# In[133]:


# Target vs AMT_INCOME_BUCKET

app_data.AMT_INCOME_BUCKET.value_counts()


# In[134]:


sns.barplot(data = app_data,x = 'TARGET',y = 'AMT_INCOME_BUCKET')
plt.show()


# In[135]:


app_data.groupby(by = 'AMT_INCOME_BUCKET')['TARGET'].mean()


# In[136]:


# AMT_CREDIT_BUCKET vs Target

app_data.AMT_CREDIT_BUCKET.value_counts()


# In[137]:


sns.barplot(data = app_data,x = 'TARGET',y = 'AMT_CREDIT_BUCKET')
plt.show()


# In[138]:


#NAME_FAMILY_STATUS vs TARGET

app_data.NAME_FAMILY_STATUS.value_counts()


# In[139]:


sns.barplot(data = app_data,x = 'TARGET',y = 'NAME_FAMILY_STATUS')
plt.show()


# In[140]:


# Code Gender VS TARGET

app_data.groupby(by = 'CODE_GENDER')['TARGET'].mean()


# In[141]:


sns.barplot(data = app_data,x = 'TARGET',y = 'CODE_GENDER')
plt.show()


# In[143]:


#Creating a bar plot to understand the relation between TARGET Column and NAME_CONTRACT_TYPE.

sns.barplot(data = app_data,x = 'TARGET',y = 'NAME_CONTRACT_TYPE')
plt.show()


# # Multivariate Analysis

# In[144]:


#Creating a Pivot Table to understand the relation between EDUCATION,Gender and Target Column.

app_table = pd.pivot_table(data = app_data, index = 'NAME_EDUCATION_TYPE', columns = 'CODE_GENDER', values = 'TARGET')


# In[145]:


app_table


# In[147]:


sns.heatmap(app_table, cmap='Greens',annot=True)
plt.show()


# In[148]:


#Creating a Pivot Table to understand the relation between Income,Gender and Target Column.

app_table2 = pd.pivot_table(data = app_data, index = 'AMT_INCOME_BUCKET', columns = 'CODE_GENDER', values = 'TARGET')


# In[149]:


sns.heatmap(app_table2,cmap='Greens',annot=True)
plt.show()


# In[150]:



#Creating a Pivot Table to understand the relation between Occupation,Gender and Target Column.
app_table3 = pd.pivot_table(data = app_data, index = 'OCCUPATION_TYPE', columns = 'NAME_EDUCATION_TYPE', values = 'TARGET')


# In[151]:


plt.figure(figsize=[8,8])
sns.heatmap(app_table3,cmap='YlGn')


# #  Analysis of Previous Application Data

# In[152]:


#Loading Application Data and saving it to p_app_data.
p_app_data = pd.read_csv('previous_application.csv')


# In[153]:


p_app_data.shape


# In[154]:


p_app_data.head()


# In[155]:


#Finding null values in the p_app_data.
p_app_data.isnull().sum()


# In[156]:


#Creating percentage values for null values.
p_null_values = ((p_app_data.isnull().sum()/len(p_app_data))*100).sort_values(ascending=False)


# ## Dropping the columns where null values is greater then 40%

# In[157]:


drop_null = p_null_values[p_null_values>40].index


# In[158]:


p_app_data.drop(drop_null,axis = 1, inplace = True)


# In[159]:


p_app_data.shape


# In[160]:


p_app_data.isnull().sum()


# # Merging of Application Data with Previous application Data on SK_ID_CURR and TARGET column.

# In[161]:



new_data = pd.merge(app_data,p_app_data,how = 'inner',on = 'SK_ID_CURR')


# In[163]:


#Finding Counts for Name_Contract_status.
new_data.NAME_CONTRACT_STATUS.value_counts().plot.barh()
plt.show()


# In[164]:


# Finding different types of clients
new_data.NAME_CLIENT_TYPE.value_counts()


# In[165]:


# REplacing XNA values to mode value for client types.
new_data.NAME_CLIENT_TYPE = new_data.NAME_CLIENT_TYPE.replace('XNA','Repeater')


# In[166]:


new_data.NAME_CLIENT_TYPE.value_counts().plot.pie()
plt.show()


# In[167]:


# Understanding the types of data in Name Portfolio.
new_data.NAME_PORTFOLIO.value_counts()


# In[169]:


#Replacing XNA values to NaN values and dropping the same.
new_data.NAME_PORTFOLIO = new_data.NAME_PORTFOLIO.replace('XNA',np.NaN)
new_data.NAME_PORTFOLIO = new_data.NAME_PORTFOLIO.dropna()


# In[170]:


new_data.NAME_PORTFOLIO.value_counts().plot.pie()
plt.show()


# In[171]:


# Understanding Type of contract type.
new_data.NAME_CONTRACT_TYPE_y.value_counts()


# In[172]:


Contract_mode = new_data.NAME_CONTRACT_TYPE_y.mode()[0]


# In[173]:


# Replcaing XNA values with Mode values of Contract type.
new_data.NAME_CONTRACT_TYPE_y = new_data.NAME_CONTRACT_TYPE_y.replace('XNA',Contract_mode)


# In[174]:


new_data.NAME_CONTRACT_TYPE_y.value_counts()


# In[175]:


new_data.NAME_CONTRACT_TYPE_y.value_counts().plot.pie()
plt.show()


# In[176]:


#Understanding Cash loan purpose column.
new_data.NAME_CASH_LOAN_PURPOSE.value_counts()


# In[177]:


# Replacing XAP values with NaN values.
new_data.NAME_CASH_LOAN_PURPOSE = new_data.NAME_CASH_LOAN_PURPOSE.replace('XAP',np.NaN)


# In[178]:


#Replacing XNA values with NaN values.
new_data.NAME_CASH_LOAN_PURPOSE = new_data.NAME_CASH_LOAN_PURPOSE.replace('XNA',np.NaN)


# In[179]:


# Dropping NaN values from the column.
new_data.NAME_CASH_LOAN_PURPOSE = new_data.NAME_CASH_LOAN_PURPOSE.dropna()


# In[180]:


# Plotting bar plot to understand different counts.
new_data.NAME_CASH_LOAN_PURPOSE.value_counts().plot.bar()
plt.show()


# In[181]:


# Understanding Name Goods category.
new_data.NAME_GOODS_CATEGORY.value_counts()


# In[182]:


# Replacing XNA values with NaN values.
new_data.NAME_GOODS_CATEGORY = new_data.NAME_GOODS_CATEGORY.replace('XNA',np.NaN)


# In[183]:


# Dropping NaN values
new_data.NAME_GOODS_CATEGORY = new_data.NAME_GOODS_CATEGORY.dropna()


# In[184]:


plt.figure(figsize = [8,8])
new_data.NAME_GOODS_CATEGORY.value_counts().plot.barh()
plt.show()


# # Bivariate Analysis

# In[185]:


# Creating Bar plot for Target variable and NAME Contract Status.
sns.barplot(data = new_data, x = 'TARGET', y = 'NAME_CONTRACT_STATUS')
plt.show()


# In[186]:


# Creating Bar plot for Target variable and NAME Client Type.

sns.barplot(data = new_data, x = 'TARGET', y = 'NAME_CLIENT_TYPE')
plt.show()


# In[187]:


# Creating Bar plot for Target variable and NAME Cash loan Purpose.

sns.barplot(data = new_data, x = 'TARGET', y = 'NAME_CASH_LOAN_PURPOSE')
plt.show()


# In[188]:


# Creating Bar plot for Target variable and NAME Goods category.

plt.figure(figsize=[8,8])
sns.barplot(data = new_data, x = 'TARGET', y = 'NAME_GOODS_CATEGORY')
plt.show()


# In[189]:


# Creating Bar plot for Target variable and NAME Contract Type.

sns.barplot(data = new_data, x = 'TARGET', y = 'NAME_CONTRACT_TYPE_y')
plt.show()


# # Multivariate Analysis

# In[190]:


#Creating Pivot Table for Name client type, name contract status and target variable.
table = pd.pivot_table(data=new_data, index = 'NAME_CLIENT_TYPE', columns = 'NAME_CONTRACT_STATUS', values = 'TARGET')


# In[191]:


table


# In[192]:


sns.heatmap(table,cmap= 'Reds')
plt.show()


# In[193]:


#Creating Pivot Table for Name contract type, name contract status and target variable.

table2 = pd.pivot_table(data=new_data, index = 'NAME_CONTRACT_TYPE_y', columns = 'NAME_CONTRACT_STATUS', values = 'TARGET')


# In[194]:


table2


# In[195]:


sns.heatmap(table2,cmap= 'Blues')
plt.show()

